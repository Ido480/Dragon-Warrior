using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
  void OnTriggerEnter2D (Collider2D otherObject)
    {
        if (otherObject.CompareTag("coins"))
        {
           Destroy(otherObject.gameObject);
        }
    }
}
