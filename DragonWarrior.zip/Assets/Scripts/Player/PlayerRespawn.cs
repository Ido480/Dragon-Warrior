using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    [SerializeField] private AudioClip checkpointSound; // Sound to play when picking up a new checkpoint
    private Transform currentCheckpoint; // Stores the current checkpoint
    private Health playerHealth;
    private UIManager uiManager;
    [SerializeField] private Rigidbody2D rb;

    // variables for respawn management
    private bool hasRespawned = false; // Track if the player has respawned already
    // private bool isDead = false; // Track if the player is dead, also not needed now

    private void Awake()
    {
        playerHealth = GetComponent<Health>();
        rb = GetComponent<Rigidbody2D>();
        uiManager = Object.FindFirstObjectByType<UIManager>();
    }
    public void CheckRespawn()
    {
        if (hasRespawned)
        {
            uiManager.GameOver();
            return;
        }

        if (currentCheckpoint == null)
        {
            uiManager.GameOver();
            return;
        }

        // Respawn the player
        transform.position = currentCheckpoint.position; // Move player to checkpoint
        playerHealth.Respawn(); // Reset player's health

        // Move camera to checkpoint room
        Camera.main.GetComponent<CameraController>().MoveToNewRoom(currentCheckpoint.parent);

        // Set the respawn flag to true so they can�t respawn again
        hasRespawned = true;

        SoundManager.instance.PlaySound(checkpointSound);
        rb.constraints = RigidbodyConstraints2D.None;
    }

    // Activate the checkpoint and disable further interactions
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.transform.CompareTag("Checkpoint") && !hasRespawned)
        {
            currentCheckpoint = collision.transform;
            SoundManager.instance.PlaySound(checkpointSound);
            collision.GetComponent<Collider2D>().enabled = false;
            collision.GetComponent<Animator>().SetTrigger("appear");
        }
    }

    /*public void PlayerDied()
    {
        if (!isDead)
        {
            isDead = true;
            rb.constraints = RigidbodyConstraints2D.FreezePosition;
            Debug.Log(playerHealth.ToString());
            CheckRespawn();
        }
    }*/ //saving in cane of future use
}