using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float speed = 2f;
    [SerializeField] float jumpForce = 5f;
    [SerializeField] float doubleJumpForce = 5f;
    [SerializeField] Transform groundPoint;
    [SerializeField] Vector2 groundSize = new Vector2(1, 0.2f);
    [SerializeField] LayerMask groundLayer;
    [SerializeField] LayerMask wallLayer;
    Animator anim;
    Rigidbody2D rigidBody;
    float horizontalInput;
    bool isJumping = false;
    bool isDoubleJumpAvailable = true;

    [Header("SFX")]
    [SerializeField] private AudioClip jumpSound;

    void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        GatherInput();
        //Flip player when moving left-right
        if (horizontalInput > 0.01)
            transform.localScale = Vector3.one;
        else if (horizontalInput < -0.01)
            transform.localScale = new Vector3(-1, 1, 1);
        //Set animator parameters
        anim.SetBool("run", horizontalInput != 0);
        anim.SetBool("checkgrounded", CheckGrounded());
    }

    void FixedUpdate()
    {
        Move();
        if (isJumping == true)
        {
            Jump();
        }
    }

    void Jump()
    {
        isJumping = false;
        if (CheckGrounded() == true)
        {
            SoundManager.instance.PlaySound(jumpSound);
            isDoubleJumpAvailable = true;
            rigidBody.linearVelocityY = 0;
            rigidBody.AddForceY(jumpForce, ForceMode2D.Impulse);
        }
        else if (isDoubleJumpAvailable == true)
        {
            SoundManager.instance.PlaySound(jumpSound);
            isDoubleJumpAvailable = false;
            rigidBody.linearVelocityY = 0;
            rigidBody.AddForceY(doubleJumpForce, ForceMode2D.Impulse);
        }
        anim.SetTrigger("jump");
    }

    void Move()
    {
        rigidBody.linearVelocityX = horizontalInput * speed;
    }

    void GatherInput()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        if (Input.GetKeyDown(KeyCode.Space))
        {
            isJumping = true;
        }
    }

    bool CheckGrounded()
    {
        if (Physics2D.OverlapBox(groundPoint.position, groundSize, 0, groundLayer))
        {
            return true;
        }
        else
        {
            return false;
        }

    }
    public bool canAttack()
    {
        return horizontalInput == 0 && CheckGrounded();
    }
}