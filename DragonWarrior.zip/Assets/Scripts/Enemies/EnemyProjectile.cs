using UnityEngine;

public class EnemyProjectile : EnemyDamage // Will damage the player every time they touch
{
    [SerializeField] float speed;
    [SerializeField] float resetTime;
    private float lifetime;
    private Animator anim;
    private BoxCollider2D boxCollider;

    private bool hit;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
    }

    public void ActivateProjectile()
    {
        hit = false;
        lifetime = 0;
        gameObject.SetActive(true);
        boxCollider.enabled = true;
    }
    private void Update()
    {
        if (hit) return;
        float movementSpeed = speed * Time.deltaTime;
        transform.Translate(movementSpeed, 0, 0);

        lifetime += Time.deltaTime;
        if (lifetime > resetTime) 
            gameObject.SetActive(true);
    }
    private new void OnTriggerEnter2D(Collider2D collision)
    {
        hit = true;
        base.OnTriggerEnter2D(collision); // Execute logic from parent class
        boxCollider.enabled = false;

        if (anim != null)
        {
            anim.SetTrigger("explode");
        }
        else
            gameObject.SetActive(false);
    }
    private void Deactivate()
    {
        gameObject.SetActive(false);
    }
}
