using UnityEngine;
using UnityEngine.SceneManagement;
public class FinalDoor : MonoBehaviour
{
    [SerializeField] private string mainMenuSceneName = "_MainMenu"; 

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            LoadMainMenu();
        }
    }

    private void LoadMainMenu()
    {
        Debug.Log("Game Completed! Returning to Main Menu...");

        SceneManager.LoadScene(mainMenuSceneName);
    }
}
